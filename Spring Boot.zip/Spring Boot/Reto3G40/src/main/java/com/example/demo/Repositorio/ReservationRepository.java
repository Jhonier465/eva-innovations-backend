/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo.Repositorio;

import com.example.demo.Interface.ReservationInterface;
import com.example.demo.Modelo.Category;
import org.springframework.stereotype.Repository;
import com.example.demo.Modelo.Reservation;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
/**
 *
 * @author USUARIO
 */

@Repository

public class ReservationRepository {
     @Autowired
    private ReservationInterface extencionesCrud;
    
    public List<Reservation> getAll(){
        return (List<Reservation>) extencionesCrud.findAll();
    }
    
    public Optional<Reservation> getReservation(int id){
        return extencionesCrud.findById(id);
    }
    
    public Reservation save(Reservation reservation){
        return extencionesCrud.save(reservation);
    }

    public void deleteReservation(int id){
        extencionesCrud.deleteById(id);
    }
    public Reservation modifyReservation(int id, Reservation reservation) {
        return extencionesCrud.findById(id)
                .map(reservation1 -> {
                    reservation1.setClient(reservation.getClient());
                    reservation1.setRoom(reservation.getRoom());
                    reservation1.setScore(reservation.getScore());
                    reservation1.setStatus(reservation.getStatus());
                    reservation1.setDevolutionDate(reservation.getDevolutionDate());
                    reservation1.setStartDate(reservation.getStartDate());
                    return extencionesCrud.save(reservation1);
                })
                .orElseGet(() -> {
                    reservation.setIdReservation(id);
                    return extencionesCrud.save(reservation);
                });
    }
}
