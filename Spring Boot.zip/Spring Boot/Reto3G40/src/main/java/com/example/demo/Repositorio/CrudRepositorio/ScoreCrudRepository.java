package com.example.demo.Repositorio.CrudRepositorio;
import com.example.demo.Modelo.Score;
import org.springframework.data.repository.CrudRepository;


public interface ScoreCrudRepository extends CrudRepository<Score,Integer> {
}
