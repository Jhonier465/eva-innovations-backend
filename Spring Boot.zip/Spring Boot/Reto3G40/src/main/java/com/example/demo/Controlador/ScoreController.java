/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo.Controlador;

import com.example.demo.Modelo.Category;
import com.example.demo.Modelo.Score;
import com.example.demo.Servicio.ScoreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author USUARIO
 */

@RestController
@RequestMapping("/api/Score")

public class ScoreController {
     @Autowired
    private ScoreService scoreService;
    @CrossOrigin
    @GetMapping("/all")
    public List<Score> getAll(){
        return scoreService.getAll();
    }
    @CrossOrigin
    @GetMapping("/{id}")
    public Optional<Score> getScore(@PathVariable("id") int id){
        return scoreService.getScore(id);
    }
    @CrossOrigin
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public Score save (@RequestBody Score score){
        return scoreService.save(score);
    }
    @CrossOrigin
    @DeleteMapping ("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteScore(@PathVariable("id") int id ){scoreService.deleteScore(id);}
    @CrossOrigin
    @PutMapping("/{id}")
    public Score modifyScore(@RequestBody Score score, @PathVariable("id") int id ){ return scoreService.modifyScore(id,score); }

}
