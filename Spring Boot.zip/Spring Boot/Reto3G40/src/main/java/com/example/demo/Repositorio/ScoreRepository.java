/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo.Repositorio;

import com.example.demo.Interface.ScoreInterface;
import com.example.demo.Modelo.Category;
import com.example.demo.Modelo.Score;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author USUARIO
 */

@Repository

public class ScoreRepository {
     @Autowired
    private ScoreInterface extencionesCrud;
    
    public List<Score> getAll(){
        return (List<Score>) extencionesCrud.findAll();
    }
    
    public Optional<Score> getScore(int id){
        return extencionesCrud.findById(id);
    }
    
    public Score save(Score score){
        return extencionesCrud.save(score);
    }

    public void deleteScore(int id){
        extencionesCrud.deleteById(id);
    }
    public Score modifyScore(int id, Score score) {
        return extencionesCrud.findById(id)
                .map(score1 -> {
                    score1.setReservation(score.getReservation());
                    score1.setStars(score.getStars());
                    score1.setMessageText(score.getMessageText());
                    return extencionesCrud.save(score1);
                })
                .orElseGet(() -> {
                    score.setIdScore(id);
                    return extencionesCrud.save(score);
                });
    }
    
}
