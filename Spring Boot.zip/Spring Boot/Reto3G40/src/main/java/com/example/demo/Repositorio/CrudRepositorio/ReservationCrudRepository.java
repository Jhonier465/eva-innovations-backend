package com.example.demo.Repositorio.CrudRepositorio;
import com.example.demo.Modelo.Reservation;
import org.springframework.data.repository.CrudRepository;


public interface ReservationCrudRepository extends CrudRepository<Reservation,Integer> {
}
