package com.example.demo.Repositorio.CrudRepositorio;
import com.example.demo.Modelo.Admin;
import org.springframework.data.repository.CrudRepository;


public interface AdminCrudRepository extends CrudRepository<Admin,Integer> {
}
