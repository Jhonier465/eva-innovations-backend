package com.example.demo.Repositorio.CrudRepositorio;
import com.example.demo.Modelo.Client;
import org.springframework.data.repository.CrudRepository;


public interface ClientCrudRepository extends CrudRepository<Client,Integer> {
}
