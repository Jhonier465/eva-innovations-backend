/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo.Controlador;

import com.example.demo.Modelo.Category;
import org.springframework.web.bind.annotation.*;
import com.example.demo.Modelo.Message;
import com.example.demo.Servicio.MessageService;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;

/**
 *
 * @author USUARIO
 */

@RestController
@RequestMapping("/api/Message")

public class MessageController {
      @Autowired
    private MessageService messageService;
    @CrossOrigin
    @GetMapping("/all")
    public List<Message> getAll(){
        return messageService.getAll();
    }
    @CrossOrigin
    @GetMapping("/{id}")
    public Optional<Message> getMessage(@PathVariable("id") int id){
        return messageService.getMessage(id);
    }
    @CrossOrigin
    @PostMapping("/save")
    @ResponseStatus(HttpStatus.CREATED)
    public Message save (@RequestBody Message message){
        return messageService.save(message);
    }
    @CrossOrigin
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteMessage(@PathVariable("id") int id ){messageService.deleteMessage(id);}
    @CrossOrigin
    @PutMapping("/{id}")
    public Message modifyMessage(@RequestBody Message message, @PathVariable("id") int id ){ return messageService.modifyMessage(id,message); }


}
