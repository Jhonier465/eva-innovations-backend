package com.example.demo.Repositorio.CrudRepositorio;
import com.example.demo.Modelo.Message;
import org.springframework.data.repository.CrudRepository;


public interface MessageCrudRepository extends CrudRepository<Message,Integer> {
}
