/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.demo.Servicio;

import com.example.demo.Modelo.Category;
import com.example.demo.Modelo.Score;
import com.example.demo.Repositorio.ScoreRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 *
 * @author USUARIO
 */

@Service

public class ScoreService {
    @Autowired
    private ScoreRepository scoreRepository;
    
    public List<Score> getAll(){
        return scoreRepository.getAll();
    }
    
    public Optional<Score> getScore(int id){
        return scoreRepository.getScore(id);
    }
    
     public Score save (Score score){
        if (score.getIdScore() == null){
            return scoreRepository.save(score);
        } else {
            Optional<Score> score1 = scoreRepository.getScore(score.getIdScore());
            if(score1.isEmpty()){
                return scoreRepository.save(score);
            } else {
                return score;
            }
        }
    }
    public void deleteScore(int id) {scoreRepository.deleteScore(id);
    }
    public Score modifyScore(int id, Score score) { return scoreRepository.modifyScore(id,score);
    }

}
