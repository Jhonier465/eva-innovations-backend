package com.example.demo.Repositorio.CrudRepositorio;
import com.example.demo.Modelo.Room;
import org.springframework.data.repository.CrudRepository;


public interface RoomCrudRepository extends CrudRepository<Room,Integer> {
}
